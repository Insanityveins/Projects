import java.util.ArrayList;

public class ThreadChecker extends Thread{

    private ArrayList<FileThread> threads;

    public ThreadChecker(ArrayList<FileThread> threads) {
        this.threads = threads;
    }

    @Override
    public synchronized void run() {
        // wait for a thread to signal it's done
        // stop all threads and clean up
        try {
            wait();
            System.out.println("Stopping all threads");
        } catch (InterruptedException ie) {
            System.out.println("Error waiting for completion.");
        }

        for (FileThread t: threads) {
            t.interrupt();
        }

        for (FileThread t: threads) {
            t.deleteFile();
        }
    }
}
